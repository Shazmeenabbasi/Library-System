﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace LibrarySystem
{
    public partial class AddBook : Form
    {
        public AddBook()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void AddBook_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT catid, catname FROM Cat;", con);
                DataTable dts = new DataTable();
                sda.Fill(dts);
                comboBox1.DisplayMember = "catname";
                comboBox1.ValueMember = "catid";
                comboBox1.DataSource = dts;
                con.Open();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(((String.IsNullOrEmpty(comboBox1.Text)) ||(String.IsNullOrEmpty(textBox2.Text))  ||(String.IsNullOrEmpty(textBox3.Text)) ||(String.IsNullOrEmpty(textBox4.Text))))
            {

                MessageBox.Show("Enter All information");
             
            }
            else
            {
                string qry="INSERT INTO BOOK VALUES("+comboBox1.SelectedValue+",'"+textBox1.Text+"','"+textBox2.Text+"','"+textBox3.Text+"','"+textBox4.Text+"')";
                try
                {
                    SqlCommand scam = new SqlCommand(qry, con);
                    con.Open();
                    int c = scam.ExecuteNonQuery();
                    if (c > 0)
                    {
                        MessageBox.Show("Book Added Successfully");
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
