﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class addstd : Form
    {
        public addstd()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void addstd_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("Select Department_ID, Department_Name from dept ", con);
                con.Open();
                DataTable dtab = new DataTable();
                sda.Fill(dtab);
                comboBox1.DisplayMember = "Department_Name";
                comboBox1.ValueMember = "Department_ID";
                comboBox1.DataSource = dtab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string q="INSERT INTO Student VALUES('"+textBox1.Text+"','"+comboBox1.SelectedValue+"','"+textBox2.Text+"',"+textBox3.Text+");";
                SqlCommand scm = new SqlCommand(q, con);

                con.Open();
                int checker = scm.ExecuteNonQuery();
                if (checker > 0)
                {
                    MessageBox.Show("Student Added Succssfully");
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            finally
            {
                con.Close();
            }

        }
    }
}
