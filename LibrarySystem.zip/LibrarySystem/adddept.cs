﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class adddept : Form
    {
        public adddept()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand scm = new SqlCommand("INSERT INTO dept VALUES('" + textBox1.Text + "')", con);
                con.Open();
                int checker = scm.ExecuteNonQuery();
                if (checker > 0)
                {
                    MessageBox.Show("Department added succesfully");
                    textBox1.Text = "";
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }

        }

        private void adddept_Load(object sender, EventArgs e)
        {
            
        }
    }
}
