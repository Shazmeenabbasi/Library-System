﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class ViewIssBook : Form
    {
        public ViewIssBook()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");
        string choice = "";
        private void ViewIssBook_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scmmnd = new SqlDataAdapter("SELECT issueID, Book_ID, catname as Book_Category, Book_Name, Book_Author, Student_Name, Department_Name, IssueDate, ExpiryDate FROM Book b, dept d, Student s, Cat c, IssBook ib WHERE ib.StdID=s.Student_ID AND b.bCategoryID=c.catid AND ib.bookID=b.Book_ID AND d.Department_ID=s.Department_ID;", con);
                con.Open();
                DataTable datab = new DataTable();
                scmmnd.Fill(datab);
                dataGridView1.DataSource = datab;

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();
             }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scmmnd = new SqlDataAdapter("SELECT issueID, Book_ID, catname as Book_Category, Book_Name, Book_Author, Student_Name, Department_Name, IssueDate, ExpiryDate FROM Book b, dept d, Student s, Cat c, IssBook ib WHERE ib.StdID=s.Student_ID AND b.bCategoryID=c.catid AND ib.bookID=b.Book_ID AND d.Department_ID=s.Department_ID AND " + choice + " like '%" + textBox1.Text + "%';", con);
                con.Open();
                DataTable datab = new DataTable();
                scmmnd.Fill(datab);
                dataGridView1.DataSource = datab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.ReadOnly = false;
            choice = comboBox1.Text;
            if (choice == "Book_Category")
                choice = "catname";
        }
    }
}
