﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class updstudent : Form
    {
        public updstudent()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void updstudent_Load(object sender, EventArgs e)
        {

            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT Department_ID, Department_Name from dept;", con);
                DataTable dtab = new DataTable();
                con.Open();
                sda.Fill(dtab);
                comboBox1.DisplayMember = "Department_Name";
                comboBox1.ValueMember = "Department_ID";
                comboBox1.DataSource = dtab;

            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);

            }
            finally
            {
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {

                SqlDataAdapter scm = new SqlDataAdapter("SELECT Student_ID, Student_Name, Student_Batch, Student_RollNo,Department_Name from Student S,dept d Where s.Department_ID=d.Department_ID  AND Student_ID  like '%" + textBox1.Text + "%';", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                if (dtab.Rows.Count > 0)
                {
                    stdbox.Text = dtab.Rows[0][0].ToString();
                    textBox2.Text = dtab.Rows[0][1].ToString();
                    textBox3.Text= dtab.Rows[0][2].ToString();
                    textBox4.Text = dtab.Rows[0][3].ToString();
                    comboBox1.Text = dtab.Rows[0][4].ToString();


                }
                else
                {
                    MessageBox.Show("No Student Exist with Student ID  "+textBox1.Text);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand sc = new SqlCommand("UPDATE Student SET Student_Name='" + textBox2.Text + "' ,Department_ID=" + comboBox1.SelectedValue + ", Student_Batch=" + textBox3.Text + ", Student_RollNo=" + textBox4.Text + " Where Student_ID="+stdbox.Text+"", con);
                con.Open();
                int checker = sc.ExecuteNonQuery();
                if (checker > 0)
                {
                    MessageBox.Show("Student Updated Succssfully");
                    comboBox1.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox2.Text = "";
                    this.Hide();
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();
            }
        }
    }
}
