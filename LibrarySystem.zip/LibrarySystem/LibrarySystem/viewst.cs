﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class viewst : Form
    {
        public viewst()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void viewst_Load(object sender, EventArgs e)
        {
            try
            {

                SqlDataAdapter scm = new SqlDataAdapter("SELECT Student_ID, Student_Name, Student_Batch, Student_RollNo,Department_Name from Student S,dept d Where s.Department_ID=d.Department_ID;", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                dataGridView1.DataSource = dtab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {

                SqlDataAdapter scm = new SqlDataAdapter("SELECT Student_ID, Student_Name, Student_Batch, Student_RollNo,Department_Name from Student S,dept d Where s.Department_ID=d.Department_ID AND  " + comboBox1.Text + " like '%" + textBox1.Text + "%';", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                dataGridView1.DataSource = dtab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }
    }
}
