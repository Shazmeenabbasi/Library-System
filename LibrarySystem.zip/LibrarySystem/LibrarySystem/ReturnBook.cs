﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class ReturnBook : Form
    {
        public ReturnBook()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");
        string sid;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!(String.IsNullOrEmpty(textBox3.Text)))
            {
                try
                {
                    SqlCommand scm = new SqlCommand("INSERT INTO ReturnBook VALUES("+textBox1.Text+","+textBox2.Text+","+sid+",'"+dateTimePicker1.Text+"')", con);
                    con.Open();
                    int exec = scm.ExecuteNonQuery();
                    SqlCommand scmmn = new SqlCommand("UPDATE BOOK SET Status='Available' WHERE Book_ID=" + textBox2.Text + "", con);
                    int ffc = scmmn.ExecuteNonQuery();
                    if (exec > 0 && ffc > 0)
                    {
                        MessageBox.Show("Book Returned Successfully");
                    }

                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);

                }
                finally
                {
                    con.Close();

                }
            }
            else
            {
                MessageBox.Show("");
            }

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (!(String.IsNullOrEmpty(textBox1.Text)))
            {
                try
                {
                    //textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";

                    SqlDataAdapter scm = new SqlDataAdapter("SELECT Student_ID, issueID, Book_ID,Book_Name, Student_Name FROM BOOK, IssBook, Student WHERE Book.Book_ID=IssBook.bookID AND Student.Student_ID=IssBook.StdID AND Status='Issued' AND issueID="+textBox1.Text+";", con);
                    con.Open();
                    DataTable dtab = new DataTable();
                    scm.Fill(dtab);
                    if (dtab.Rows.Count > 0)
                    {
                        sid = dtab.Rows[0][1].ToString();
                        textBox2.Text = dtab.Rows[0][2].ToString();
                        textBox3.Text = dtab.Rows[0][3].ToString();
                        textBox4.Text = dtab.Rows[0][4].ToString();
                    }
                    else
                        MessageBox.Show("This Book is Already Returned and Available for Re-Issueiew");
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);

                }
                finally
                {
                    con.Close();

                }
            }
            else
                MessageBox.Show("Enter issue id");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void ReturnBook_Load(object sender, EventArgs e)
        {

        }
    }
}
