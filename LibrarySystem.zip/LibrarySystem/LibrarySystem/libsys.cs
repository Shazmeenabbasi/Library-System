﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class libsys : Form
    {
        public libsys()
        {
            InitializeComponent();
        }

        private void viewCategoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewcat vc = new viewcat();
            vc.MdiParent = this;
            vc.Show();
        }

        private void addCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addcat adcat = new addcat();
            adcat.MdiParent = this;
            adcat.Show();
        }

        private void updateCategoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updatecat upcat = new updatecat();
            upcat.MdiParent = this;
            upcat.Show();
        }

        private void addDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            adddept addp = new adddept();
            addp.MdiParent = this;
            addp.Show();
        }

        private void viewDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewdepartment vdprt = new viewdepartment();
            vdprt.MdiParent = this;
            vdprt.Show();
        }

        private void updateDepartmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updatedepartm updt = new updatedepartm();
            updt.MdiParent = this;
            updt.Show();
        }

        private void addStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addstd ads = new addstd();
            ads.MdiParent = this;
            ads.Show();
        }

        private void viewStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewst vs = new viewst();
            vs.MdiParent = this;
            vs.Show();
        }

        private void updateStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updstudent updstd = new updstudent();
            updstd.MdiParent = this;
            updstd.Show();
        }

        private void addBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddBook adb = new AddBook();
            adb.MdiParent = this;
            adb.Show();
        }

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewBook vb = new ViewBook();
            vb.MdiParent = this;
            vb.Show();
        }

        private void updateBookToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void issueBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void returnBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
      
        }

        private void issueBookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            IssueBook ib = new IssueBook();
            ib.MdiParent = this;
            ib.Show();
        }

        private void viewIssuedBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewIssBook vsbook = new ViewIssBook();
            vsbook.MdiParent = this;
            vsbook.Show();
        }

        private void returnBookToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReturnBook rb = new ReturnBook();
            rb.MdiParent = this;
            rb.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void viewBookReturnedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewBookReturn vbru = new viewBookReturn();
            vbru.MdiParent = this;
            vbru.Show();

        }
    }
}
