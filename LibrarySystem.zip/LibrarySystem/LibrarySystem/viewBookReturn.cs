﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class viewBookReturn : Form
    {
        public viewBookReturn()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void viewBookReturn_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scm = new SqlDataAdapter("SELECT issueID, Book_ID,Book_Name, Student_Name FROM BOOK, IssBook, Student WHERE Book.Book_ID=IssBook.bookID AND Student.Student_ID=IssBook.StdID;", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                dataGridView1.DataSource = dtab;

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scm = new SqlDataAdapter("SELECT issueID, Book_ID,Book_Name, Student_Name FROM BOOK, IssBook, Student WHERE Book.Book_ID=IssBook.bookID AND Student.Student_ID=IssBook.StdID AND Book_Name like '%"+textBox1.Text+"%' ;", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                dataGridView1.DataSource = dtab;

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }
    }
}
