﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class updatecat : Form
    {
        public updatecat()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void updatecat_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scm = new SqlDataAdapter("SELECT catname from Cat;", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                comboBox1.DisplayMember = "catname";
                comboBox1.DataSource = dtab;

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            textBox1.Text = comboBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand scm = new SqlCommand("UPDATE Cat SET catname='" + textBox1.Text + "' Where catname='" + comboBox1.Text + "'", con);
                con.Open();
                int checker = scm.ExecuteNonQuery();
                if (checker > 0)
                {
                    MessageBox.Show("category updated succesfully");
                    textBox1.Text = "";
                }

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }

        }
    }
}
