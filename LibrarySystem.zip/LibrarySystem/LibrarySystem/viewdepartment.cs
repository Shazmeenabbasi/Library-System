﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class viewdepartment : Form
    {
        public viewdepartment()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void viewdepartment_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter scm = new SqlDataAdapter("SELECT * FROM dept", con);
                con.Open();
                DataTable dtab = new DataTable();
                scm.Fill(dtab);
                dataGridView1.DataSource = dtab;

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }
    }
}
