﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class viewcat : Form
    {
        public viewcat()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");

        private void viewcat_Load(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Cat;", con);
                con.Open();
                DataTable dtab = new DataTable();
                sda.Fill(dtab);
                dataGridView1.DataSource = dtab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM Cat where catname like '%"+textBox1.Text+"%';", con);
                con.Open();
                DataTable dtab = new DataTable();
                sda.Fill(dtab);
                dataGridView1.DataSource = dtab;
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);

            }
            finally
            {
                con.Close();

            }

        }
    }
}
