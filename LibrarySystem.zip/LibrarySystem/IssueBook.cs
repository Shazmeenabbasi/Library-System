﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibrarySystem
{
    public partial class IssueBook : Form
    {
        public IssueBook()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("server=DESKTOP-90HO85L\\SQLEXPRESS;database=LIBRARY; integrated security = sspi");
        string sbb;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!(string.IsNullOrEmpty(comboBox1.Text)))
            {
                try
                {

                    SqlDataAdapter scm = new SqlDataAdapter("SELECT Book_ID,catname , Book_Name, Book_Author, Book_Edition, Book_ISBN, Status FROM Cat c, BOOK B WHERE c.catid=B.bCategoryID AND " + comboBox1.Text + " like '%" + textBox1.Text + "%';", con);
                    con.Open();
                    DataTable dtab = new DataTable();
                    scm.Fill(dtab);
                    if (dtab.Rows.Count > 0)
                    {
                        IDbox.Text = dtab.Rows[0][0].ToString();
                        cat.Text = dtab.Rows[0][1].ToString();
                        bknam.Text = dtab.Rows[0][2].ToString();
                        bauthor.Text = dtab.Rows[0][3].ToString();
                        bedition.Text = dtab.Rows[0][4].ToString();
                        bISBN.Text = dtab.Rows[0][5].ToString();
                        bstatus.Text = dtab.Rows[0][6].ToString();
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);

                }
                finally
                {
                    con.Close();

                }
            }
            else
            {
                MessageBox.Show("Select Book Search by");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!(string.IsNullOrEmpty(comboBox2.Text)))
            {
                try
                {

                    SqlDataAdapter scm = new SqlDataAdapter("SELECT Student_ID, Student_Name, Student_Batch, Student_RollNo,Department_Name from Student S,dept d Where s.Department_ID=d.Department_ID AND " + comboBox2.Text + " like '%" + textBox2.Text + "%';", con);
                    con.Open();
                    DataTable dtab = new DataTable();
                    scm.Fill(dtab);
                    if (dtab.Rows.Count > 0)
                    {
                    stdid.Text=dtab.Rows[0][0].ToString();
                    stdname.Text=dtab.Rows[0][1].ToString();
                    depname.Text=dtab.Rows[0][2].ToString();
                    stbatch.Text=dtab.Rows[0][3].ToString();
                    stdrollno.Text = dtab.Rows[0][4].ToString();
                    }
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    con.Close();

                }

            }
            else
            {
                MessageBox.Show("Select Search Student By");
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

    

        }

        private void IssueBook_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(IDbox.Text) && String.IsNullOrEmpty(stdid.Text))
            {
                MessageBox.Show("Select Student and Book First");
            }
            else if(String.IsNullOrEmpty(IDbox.Text))
            {
               MessageBox.Show("Select Book First");

            }
            else if(String.IsNullOrEmpty(stdid.Text))
            {
                MessageBox.Show("Select Student First");
            }
            else if (bstatus.Text != "Available")
            {
                MessageBox.Show("This Book is Already Issued");
            }
            else
            {

                try
                {
                    SqlCommand scm = new SqlCommand("INSERT INTO IssBook VALUES("+stdid.Text+","+IDbox.Text+",'"+dateTimePicker1.Text+"','"+dateTimePicker2.Text+"');",con);
                    con.Open();
                    int check = scm.ExecuteNonQuery();
                    if (check > 0)
                    {
                        SqlCommand scomm = new SqlCommand("UPDATE BOOK SET Status='Issued' WHERE Book_ID=" + IDbox.Text + ";", con);
                        int cc = scomm.ExecuteNonQuery();
                        if (cc > 0)
                        {
                            SqlDataAdapter sq = new SqlDataAdapter("SELECT CASE WHEN (SELECT COUNT(1) FROM IssBook)=0 THEN 1 ELSE IDENT_CURRENT('IssBook') END AS Current_Identity;", con);
                            DataTable dtab = new DataTable();
                            sq.Fill(dtab);
                            string issueId= dtab.Rows[0][0].ToString();
                            MessageBox.Show("Book Issued Successfully, Issue ID is: " + issueId);
                            this.Close();
                        }
                    }
              
                }
                catch (Exception err)
                {
                    MessageBox.Show(err.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
